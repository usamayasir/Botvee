import { NextRequest, NextResponse } from 'next/server';
import { AppDataSource } from '@/config/database';
import { Conversation } from '@/entities/Conversation';
import { User } from '@/entities/User';

/**
 * GET /api/conversations
 * Fetch active conversations for human handoff interface
 * Query params:
 *   - status: 'active' | 'waiting' | 'idle' | 'completed' (optional)
 *   - mode: 'AI' | 'Human' (optional)
 *   - assignedTo: userId (optional)
 *   - botId: botId (optional) - filter conversations by specific bot
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const mode = searchParams.get('mode');
    const assignedTo = searchParams.get('assignedTo');
    const botId = searchParams.get('botId');

    // Initialize database
    if (!AppDataSource.isInitialized) {
      try {
        await AppDataSource.initialize();
      } catch (error) {
        console.error('Database initialization failed:', error);
        return NextResponse.json(
          {
            success: false,
            error: 'Database connection failed'
          },
          { status: 500 }
        );
      }
    }

    const conversationRepository = AppDataSource.getRepository(Conversation);

    // Build query
    const queryBuilder = conversationRepository
      .createQueryBuilder('conversation')
      .leftJoinAndSelect('conversation.bot', 'bot')
      .leftJoinAndSelect('conversation.user', 'user')
      .leftJoinAndSelect('conversation.assignedAgent', 'assignedAgent')
      .orderBy('conversation.lastMessageAt', 'DESC')
      .addOrderBy('conversation.createdAt', 'DESC');

    // Apply filters
    if (status) {
      queryBuilder.andWhere('conversation.status = :status', { status });
    }

    if (mode) {
      queryBuilder.andWhere('conversation.mode = :mode', { mode });
    }

    if (assignedTo) {
      queryBuilder.andWhere('conversation.assignedAgentId = :assignedTo', { assignedTo });
    }

    if (botId) {
      queryBuilder.andWhere('conversation.botId = :botId', { botId });
    }

    // Exclude completed/closed conversations by default unless specifically requested
    if (!status) {
      queryBuilder.andWhere('conversation.status IN (:...statuses)', {
        statuses: ['active', 'waiting', 'idle']
      });
    }

    const conversations = await queryBuilder.getMany();

    // Transform to frontend format
    const formattedConversations = conversations.map(conv => {
      const fallbackId = conv.sessionId?.slice(-4) || conv.id.slice(-4);
      return {
        id: conv.id,
        sessionId: conv.sessionId,
        guestName: conv.guestName || `Guest #${fallbackId}`,
        guestId: conv.guestId || `LC-${fallbackId}`,
        mode: conv.mode,
        status: conv.status,
        messages: conv.messages || [],
        lastMessage: conv.messages?.length > 0
          ? conv.messages[conv.messages.length - 1].text
          : 'No messages yet',
        timestamp: conv.lastMessageAt
          ? getRelativeTime(new Date(conv.lastMessageAt))
          : 'Just now',
        botName: conv.bot?.name,
        assignedAgent: conv.assignedAgent
          ? {
              id: conv.assignedAgent.id,
              name: conv.assignedAgent.firstName && conv.assignedAgent.lastName
                ? `${conv.assignedAgent.firstName} ${conv.assignedAgent.lastName}`
                : conv.assignedAgentName || conv.assignedAgent.email?.split('@')[0] || 'Agent',
              email: conv.assignedAgent.email
            }
          : null,
        assignedAt: conv.assignedAt,
        createdAt: conv.createdAt,
        lastMessageAt: conv.lastMessageAt,
        metadata: conv.metadata
      };
    });

    return NextResponse.json({
      success: true,
      conversations: formattedConversations,
      total: formattedConversations.length
    });

  } catch (error) {
    console.error('Error fetching conversations:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch conversations',
        message: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

/**
 * Helper function to get relative time string
 */
function getRelativeTime(date: Date): string {
  const now = new Date();
  const diffInMs = now.getTime() - date.getTime();
  const diffInMins = Math.floor(diffInMs / 60000);
  const diffInHours = Math.floor(diffInMs / 3600000);
  const diffInDays = Math.floor(diffInMs / 86400000);

  if (diffInMins < 1) return 'Just now';
  if (diffInMins < 60) return `${diffInMins} min${diffInMins > 1 ? 's' : ''} ago`;
  if (diffInHours < 24) return `${diffInHours} hour${diffInHours > 1 ? 's' : ''} ago`;
  return `${diffInDays} day${diffInDays > 1 ? 's' : ''} ago`;
}
